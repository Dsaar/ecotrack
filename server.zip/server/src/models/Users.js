import mongoose from "mongoose";
import { Name } from "../helpers/submodels/Name.js";
import { Address } from "../helpers/submodels/Address.js";
import { Image } from "../helpers/submodels/Image.js";

const { Schema } = mongoose;

const userSchema = new Schema(
	{
		name: { type: Name, required: true },
		email: {
			type: String,
			required: true,
			unique: true,
			lowercase: true,
			trim: true,
		},
		passwordHash: { type: String, required: true },
		phone: { type: String, trim: true },
		address: { type: Address },
		avatar: { type: Image },
		role: {
			type: String,
			enum: ["user", "admin"],
			default: "user",
		},
		points: { type: Number, default: 0 },
		favorites: {
			missionFavorites: [{ type: Schema.Types.ObjectId, ref: "Mission" }],
			submissionFavorites: [{ type: Schema.Types.ObjectId, ref: "Submission" }],
		},
	},
	{ timestamps: true }
);

const User = mongoose.model("User", userSchema);
export default User;
