import Joi from "joi";

export const passwordRegex =
	/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[ !"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]).{8,}$/;

export const registerSchema = Joi.object({
	name: Joi.object({
		first: Joi.string().min(2).max(256).required(),
		middle: Joi.string().min(2).max(256).allow(""),
		last: Joi.string().min(2).max(256).required(),
	}).required(),

	phone: Joi.string()
		.ruleset.regex(/0[0-9]{1,2}-?\s?[0-9]{3}\s?[0-9]{4}/)
		.rule({ message: 'user "phone" must be a valid phone number' })
		.required(),

	email: Joi.string()
		.ruleset.regex(
			/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/
		)
		.rule({ message: 'user "mail" must be a valid mail' })
		.required(),

	password: Joi.string()
		.pattern(passwordRegex)
		.required()
		.messages({
			"string.pattern.base":
				'user "password" must be at least 8 chars and contain upper, lower, number and symbol',
		}),

	avatar: Joi.object({
		url: Joi.string()
			.pattern(
				/(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,})/
			)
			.message("user image must be a valid url")
			.allow(""),
		alt: Joi.string().min(2).max(256).allow(""),
	}).optional(),

	address: Joi.object({
		state: Joi.string().allow(""),
		country: Joi.string().min(2).max(256).required(),
		city: Joi.string().min(2).max(256).required(),
		street: Joi.string().min(2).max(256).required(),
		houseNumber: Joi.number().required(),
		zip: Joi.number(),
	}).optional(),
});

export const loginSchema = Joi.object({
	email: Joi.string()
		.ruleset.regex(
			/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/
		)
		.rule({ message: 'user "mail" must be a valid mail' })
		.required(),
	password: Joi.string().required(),
});
