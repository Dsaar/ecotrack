import User from "../models/Users.js";

export const getMe = async (req, res) => {
	const user = await User.findById(req.user.id);
	if (!user) return res.status(404).json({ message: "User not found" });
	res.json({
		id: user._id, name: user.name, email: user.email,
		isAdmin: user.isAdmin, points: user.points, favorites: user.favorites
	});
};

export const updateMe = async (req, res, next) => {
	try {
		// req.user is set by verifyJWT
		const userId = req.user.id || req.user._id;

		// only allow these fields to be updated by the user
		const allowedFields = ["name", "avatarUrl", "phone", "address"];
		const updates = {};

		for (const key of allowedFields) {
			if (key in req.body) {
				updates[key] = req.body[key];
			}
		}

		if (Object.keys(updates).length === 0) {
			return res.status(400).json({ message: "No valid fields to update" });
		}

		const updatedUser = await User.findByIdAndUpdate(userId, updates, {
			new: true,
			runValidators: true,
		}).select("-passwordHash"); // don’t expose hash

		if (!updatedUser) {
			return res.status(404).json({ message: "User not found" });
		}

		res.json(updatedUser);
	} catch (err) {
		next(err);
	}
};


export const patchMe = async (req, res) => {
	try {
		const allowed = ["name", "avatarUrl"]; // extend as needed
		const updates = Object.fromEntries(
			Object.entries(req.body).filter(([k]) => allowed.includes(k))
		);
		if (!Object.keys(updates).length) {
			return res.status(400).json({ message: "No updatable fields provided" });
		}
		const user = await User.findByIdAndUpdate(
			req.user.id,
			{ $set: updates },
			{ new: true, runValidators: true }
		);
		if (!user) return res.status(404).json({ message: "User not found" });
		const { _id, name, email, isAdmin, points, favorites, avatarUrl } = user;
		return res.json({ id: _id, name, email, isAdmin, points, favorites, avatarUrl });
	} catch (err) {
		console.error("[patchMe]", err);
		return res.status(500).json({ message: "Failed to update user" });
	}
};



// ---- Admin only ----
export const listUsers = async (_req, res) => {
	const users = await User.find().select("name email isAdmin points");
	res.json(users);
};

export const deleteUser = async (req, res) => {
	const { id } = req.params;
	await User.findByIdAndDelete(id);
	res.status(204).end();
};

export const adminUpdateUser = async (req, res) => {
	try {
		const allowed = ["name", "avatarUrl", "isAdmin"]; // admin may toggle role
		const updates = Object.fromEntries(
			Object.entries(req.body).filter(([k]) => allowed.includes(k))
		);
		if (!Object.keys(updates).length) {
			return res.status(400).json({ message: "No updatable fields provided" });
		}

		const user = await User.findByIdAndUpdate(
			req.params.id,
			{ $set: updates },
			{ new: true, runValidators: true }
		);

		if (!user) return res.status(404).json({ message: "User not found" });

		const { _id, name, email, isAdmin, points, favorites, avatarUrl } = user;
		return res.json({
			id: _id,
			name,
			email,
			isAdmin,
			points,
			favorites,
			avatarUrl,
		});
	} catch (err) {
		console.error("[adminUpdateUser]", err);
		return res.status(500).json({ message: "Failed to update user" });
	}
};
