// seed/seed.js
import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import config from "config";

import User from "../src/models/Users.js";
import { users } from "./data/userSeed.js";

dotenv.config();

/* =========================================================================
   ENV GUARDS — refuse to seed prod unless explicit override
   ========================================================================= */
const nodeEnv = process.env.NODE_ENV || "development";
const dbEnv =
	(config.has("DB_ENVIRONMENT") && config.get("DB_ENVIRONMENT")) || "local";

if ((nodeEnv === "production" || dbEnv !== "local") && !process.env.ALLOW_SEED_ANYWAY) {
	console.error(`❌ Refusing to seed. NODE_ENV=${nodeEnv}, DB_ENVIRONMENT=${dbEnv}.`);
	console.error("   This script seeds only development/local by default.");
	console.error("   Set ALLOW_SEED_ANYWAY=true to override (NOT recommended for prod).");
	process.exit(1);
}

/* =========================
   DB CONNECTION
   ========================= */
function pickMongoUri() {
	if (process.env.MONGODB_URI) return process.env.MONGODB_URI;
	return dbEnv === "local" ? process.env.LOCAL_DB : process.env.ATLAS_DB;
}

async function connect() {
	const uri = pickMongoUri();
	if (!uri) {
		console.error("❌ No MongoDB URI. Set MONGODB_URI, or LOCAL_DB/ATLAS_DB + DB_ENVIRONMENT.");
		process.exit(1);
	}
	console.log("Seeding: connecting to MongoDB...");
	await mongoose.connect(uri);
	console.log("✅ Connected for seed");
}

async function disconnect() {
	await mongoose.disconnect();
	console.log("👋 Seed: disconnected");
}

/* =========================
   UPSERT USERS (idempotent)
   ========================= */
async function upsertUser(u) {
	const normalizedEmail = String(u.email).trim().toLowerCase();
	const passwordHash = await bcrypt.hash(u.password, 12);

	await User.updateOne(
		{ email: normalizedEmail },
		{
			$setOnInsert: {
				email: normalizedEmail,
				passwordHash,
				name: u.name,
				phone: u.phone,
				address: u.address,
				avatar: u.avatar,
				role: u.role || "user",
				points: u.points ?? 0,
				favorites: u.favorites ?? {
					missionFavorites: [],
					submissionFavorites: [],
				},
			},
		},
		{ upsert: true }
	);

	const created = await User.findOne({ email: normalizedEmail });
	console.log(`👤 User ready: ${created.email} (role=${created.role})`);
	return created;
}

/* =========================
   MAIN
   ========================= */
(async function main() {
	try {
		await connect();
		for (const u of users) {
			await upsertUser(u);
		}
		console.log("🌱 EcoTrack seeding complete.");
	} catch (err) {
		console.error("❌ Seed failed:", err);
		process.exitCode = 1;
	} finally {
		await disconnect();
	}
})();
