export const users = [
	{
		key: "regular",
		email: "regular@ecotrack.com",
		password: "User123!",
		name: { first: "Reg", middle: "", last: "User" },
		phone: "050-1234567",
		address: {
			country: "Israel",
			city: "Tel Aviv",
			street: "Herzl",
			houseNumber: 12,
			zip: 61000,
			state: "",
		},
		avatar: {
			url: "https://picsum.photos/seed/ecoregular/300/300",
			alt: "regular user avatar",
		},
		role: "user",
		points: 0,
		favorites: {
			missionFavorites: [],
			submissionFavorites: [],
		},
	},

	{
		key: "user2",
		email: "noa@ecotrack.com",
		password: "User123!",
		name: { first: "Noa", middle: "", last: "Levi" },
		phone: "052-2223333",
		address: {
			country: "Israel",
			city: "Jerusalem",
			street: "Jabotinsky",
			houseNumber: 5,
			zip: 94500,
			state: "",
		},
		avatar: {
			url: "https://picsum.photos/seed/econoalevi/300/300",
			alt: "Noa avatar",
		},
		role: "user",
		points: 15,
		favorites: {
			missionFavorites: [],
			submissionFavorites: [],
		},
	},

	{
		key: "admin",
		email: "admin@ecotrack.com",
		password: "Admin123!",
		name: { first: "Eco", middle: "", last: "Admin" },
		phone: "053-7778888",
		address: {
			country: "Israel",
			city: "Haifa",
			street: "Ben Gurion",
			houseNumber: 1,
			zip: 35000,
			state: "",
		},
		avatar: {
			url: "https://picsum.photos/seed/ecoadmin/300/300",
			alt: "admin avatar",
		},
		role: "admin",
		points: 999,
		favorites: {
			missionFavorites: [],
			submissionFavorites: [],
		},
	},
];
